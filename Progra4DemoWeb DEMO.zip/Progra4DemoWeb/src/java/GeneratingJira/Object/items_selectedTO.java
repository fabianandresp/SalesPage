/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Object;

import java.io.InputStream;
import java.io.Serializable;

/**
 *
 * @author pimie
 */
public class items_selectedTO implements Serializable {

    private int id_item;
    private int id_carrito;
    private int item_cantidad;
    private String item_nombre;
    private int item_precio;
    private String item_ruta;

    public items_selectedTO(int id_item, int id_carrito, int item_cantidad, String item_nombre, int item_precio, String item_ruta) {
        this.id_item = id_item;
        this.id_carrito = id_carrito;
        this.item_cantidad = item_cantidad;
        this.item_nombre = item_nombre;
        this.item_precio = item_precio;
        this.item_ruta = item_ruta;
    }

    public items_selectedTO() {
    }

    public int getId_item() {
        return id_item;
    }

    public void setId_item(int id_item) {
        this.id_item = id_item;
    }

    public int getId_carrito() {
        return id_carrito;
    }

    public void setId_carrito(int id_carrito) {
        this.id_carrito = id_carrito;
    }

    public int getItem_cantidad() {
        return item_cantidad;
    }

    public void setItem_cantidad(int item_cantidad) {
        this.item_cantidad = item_cantidad;
    }

    public String getItem_nombre() {
        return item_nombre;
    }

    public void setItem_nombre(String item_nombre) {
        this.item_nombre = item_nombre;
    }

    public int getItem_precio() {
        return item_precio;
    }

    public void setItem_precio(int item_precio) {
        this.item_precio = item_precio;
    }

    public String getItem_ruta() {
        return item_ruta;
    }

    public void setItem_ruta(String item_ruta) {
        this.item_ruta = item_ruta;
    }



}
