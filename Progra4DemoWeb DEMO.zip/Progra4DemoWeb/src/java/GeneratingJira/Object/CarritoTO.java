/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Object;

import java.io.Serializable;

/**
 *
 * @author pimie
 */
public class CarritoTO implements Serializable {
    
    private int carrito_id;
    private double carrito_totalPrize;
    private double carrito_cantidadTotal;

    public CarritoTO(int carrito_id, double carrito_total, double carrito_cantidadTotal) {
        this.carrito_id = carrito_id;
        this.carrito_totalPrize = carrito_total;
        this.carrito_cantidadTotal = carrito_cantidadTotal;
    }

    public CarritoTO() {
    }
    
    public int getCarrito_id() {
        return carrito_id;
    }

    public void setCarrito_id(int carrito_id) {
        this.carrito_id = carrito_id;
    }

    public double getCarrito_totalPrize() {
        return carrito_totalPrize;
    }

    public void setCarrito_totalPrize(double carrito_totalPrize) {
        this.carrito_totalPrize = carrito_totalPrize;
    }

    public double getCarrito_cantidadTotal() {
        return carrito_cantidadTotal;
    }

    public void setCarrito_cantidadTotal(double carrito_cantidadTotal) {
        this.carrito_cantidadTotal = carrito_cantidadTotal;
    }
    
}
