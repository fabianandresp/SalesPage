package GeneratingJira.Object;

import java.io.InputStream;
import java.io.Serializable;

/**
 *
 * @author Ryan
 */
public class ItemTO implements Serializable {

    private int id;
    private String nombreItem;
    private int cantidad;
    private int precioItem;
    private String rutaImagen;
    private String nombreImagen;

    public ItemTO() {
    }

    public ItemTO(int id, String nombreItem, int cantidad, int precioItem, String rutaImagen) {
        this.id = id;
        this.nombreItem = nombreItem;
        this.cantidad = cantidad;
        this.precioItem = precioItem;
        this.rutaImagen = rutaImagen;
    }

    public ItemTO(int id, String nombreItem, int cantidad, int precioItem) {
        this.id = id;
        this.nombreItem = nombreItem;
        this.cantidad = cantidad;
        this.precioItem = precioItem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreItem() {
        return nombreItem;
    }

    public void setNombreItem(String nombreItem) {
        this.nombreItem = nombreItem;
    }

    public int getPrecioItem() {
        return precioItem;
    }

    public void setPrecioItem(int precioItem) {
        this.precioItem = precioItem;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    public String getNombreImagen() {
        return nombreImagen;
    }

    public void setNombreImagen(String nombreImagen) {
        this.nombreImagen = nombreImagen;
    }
}
