/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Object;

import java.io.Serializable;

/**
 *
 * @author pimie
 */
public class facturaTO implements Serializable{
    
    private int order_id;
    private String order_date;
    private int order_monto;
    private int user_id;

    public facturaTO(int order_id, String order_date, int order_monto, int user_id) {
        this.order_id = order_id;
        this.order_date = order_date;
        this.order_monto = order_monto;
        this.user_id = user_id;
    }

    public facturaTO() {
    }
    
    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public int getOrder_total() {
        return order_monto;
    }

    public void setOrder_total(int order_total) {
        this.order_monto = order_total;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
    
    
    
}
