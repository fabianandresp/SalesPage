/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Test;

import GeneratingJira.Servicio.conexion;
import GeneratingJira.Servicio.servicio_ItemTO;
import GeneratingJira.Servicio.servicio_carritoTO;
import GeneratingJira.Servicio.servicio_user_info;

/**
 *
 * @author pimie
 */
public class tester {
    public static void main(String[] args) {
        servicio_carritoTO testUser = new servicio_carritoTO();
        conexion test = new conexion();
        
        testUser.createNewIdCarrito();
        System.out.println(testUser.selectIdCarrito());
        test.conexion();
        
        
        
      
        
        
        
    }
}
