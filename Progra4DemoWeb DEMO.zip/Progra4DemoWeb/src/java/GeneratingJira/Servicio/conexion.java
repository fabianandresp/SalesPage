package GeneratingJira.Servicio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author pimie
 */
public class conexion {

    protected Connection con = null;
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String USER = "root";
    private static final String PASSWORD = "Superpera22";
    private static final String URL = "jdbc:mysql://localhost:3306/";
    public static String DataBaseName = "generating";

    public void conexion() {
        try {
            Class.forName(DRIVER);
            con = (Connection) DriverManager.getConnection(URL + DataBaseName, USER, PASSWORD);
            System.out.println("Successful conection");
        } catch (Exception e) {
            System.out.println("Error conection" + e);
            e.printStackTrace();
        }
    }

    public void cerrarStatement(Statement st) {
        try {
            if (st != null && !st.isClosed()) {
                st.close();
                st = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
        public void cerrarPrepareStatement(PreparedStatement st) {
        try {
            if (st != null && !st.isClosed()) {
                st.close();
                st = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cerrarResultSet(ResultSet rs) {
        try {
            if (rs != null && !rs.isClosed()) {
                rs.close();
                rs = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void desconectar() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                con = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
