package GeneratingJira.Servicio;

import GeneratingJira.Object.ItemTO;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Ryan
 */
public class servicio_ItemTO extends conexion {

    public List<ItemTO> listarItems() {

        Statement stmt = null;
        ResultSet rs = null;
        List<ItemTO> listaRetorno = new ArrayList<ItemTO>();

        try {
            conexion();
            stmt = con.createStatement();
            String sql = "SELECT * from items";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                int precio = rs.getInt("precio");
                String ruta = rs.getString("rutaImagen");
                ItemTO itemTO = new ItemTO(id, nombre, cantidad, precio, ruta);
                System.out.println(ruta);

                listaRetorno.add(itemTO);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return listaRetorno;

    }

    public void insertar(ItemTO item) {

        PreparedStatement stmt = null;
        //ResultSet rs = null;
        try {
            conexion();

            //String sql = "INSERT into items(nombre,cantidad,precio) values  (' " + item.getNombreItem() + "', '" + item.getCantidad() + "' , '" + item.getPrecioItem() + "')";
            String sql = "Insert into items (nombre, cantidad, precio, nombreImagen, rutaImagen) values (?,?,?,?,?)";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, item.getNombreItem());
            stmt.setInt(2, item.getCantidad());
            stmt.setInt(3, item.getPrecioItem());
            stmt.setString(4, item.getNombreImagen());
            stmt.setString(5, item.getRutaImagen());
            stmt.executeUpdate();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        } finally {
            //cerrarResultSet(rs);
            cerrarPrepareStatement(stmt);
            desconectar();
        }
    }

    public void actualizar(ItemTO item) {

        PreparedStatement stmt = null;
        // ResultSet rs = null;
        try {
            conexion();
            String sql = "UPDATE items SET nombre =?, cantidad =?, precio=?, nombreImagen=?, rutaImagen=? WHERE id=?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, item.getNombreItem());
            stmt.setInt(2, item.getCantidad());
            stmt.setInt(3, item.getPrecioItem());
            stmt.setString(4, item.getNombreImagen());
            stmt.setString(5, item.getRutaImagen());
            stmt.setInt(6, item.getId());
            stmt.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        } finally {
            //cerrarResultSet(rs);
            cerrarPrepareStatement(stmt);
            desconectar();
        }
    }

    public InputStream imagen(byte[] arr) {

        InputStream input = new ByteArrayInputStream(arr);
        return input;
    }

    public void eliminar(ItemTO item) {

        PreparedStatement stmt = null;
        //ResultSet rs = null;
        try {
            conexion();

            String sql = "Delete from items where id = '" + item.getId() + "'";
            stmt = con.prepareStatement(sql);
            stmt.executeUpdate();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        } finally {
            //cerrarResultSet(rs);
            cerrarPrepareStatement(stmt);
            desconectar();
        }
    }

    public int maxId() {

        Statement stmt = null;
        ResultSet rs = null;
        int id = 0;
        try {
            conexion();
            stmt = con.createStatement();
            String sql = "SELECT MAX(id) AS max_id FROM items";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {

                id = rs.getInt("max_id") + 1;

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return id;
    }

    public String pathImagen() {

        Statement stmt = null;
        ResultSet rs = null;
        String path = "";
        try {
            conexion();
            stmt = con.createStatement();
            String sql = "SELECT valor from parametros where cod_general='path_images'";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                path = rs.getString("valor");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return path;
    }

    public String urlImagen() {

        Statement stmt = null;
        ResultSet rs = null;
        String url = "SELECT valor from parametros where cod_general='url_image'";
        try {
            conexion();
            stmt = con.createStatement();
            String sql = "SELECT * from parametros";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                url = rs.getString("valor");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return url;
    }

}
