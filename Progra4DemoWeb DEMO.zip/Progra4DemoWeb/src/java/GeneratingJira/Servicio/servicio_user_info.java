package GeneratingJira.Servicio;

import GeneratingJira.Object.user_info;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import static java.sql.Types.NULL;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pimie
 */
public class servicio_user_info extends conexion {

    public void user_info_insert(user_info user) {

        if(user.getUser_type()==NULL ){
            user.setUser_type(1);
            user.setUser_status("ACTIVO");
        }
        
        PreparedStatement pps = null;
        String sql = "INSERT INTO generating.user (User_Email, User_Pass, User_Status, User_Name, User_Type_Id)  VALUES(?,?,?,?,?)";

        try {
            conexion();
            pps = con.prepareStatement(sql);
            pps.setString(1, user.getUser_email());
            pps.setString(2, user.getUser_pass());
            pps.setString(3, user.getUser_status());
            pps.setString(4, user.getUser_name());
            pps.setInt(5, user.getUser_type());

            pps.executeUpdate();

            System.out.println("Usuario ingresado con exito");
            //realizar alerta visible para el usuario
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }
    }

    public void updateUser(user_info user) {

        PreparedStatement pps = null;
        try {
            conexion();
            String sql = "UPDATE generating.user SET User_Email=?, User_Pass=?, User_Status=?, User_Name=?, User_Type_Id=? WHERE (User_Id=?)";
            pps = con.prepareStatement(sql);
            pps.setString(1, user.getUser_email());
            pps.setString(2, user.getUser_pass());
            pps.setString(3, user.getUser_status());
            pps.setString(4, user.getUser_name());
            pps.setInt(5, user.getUser_type());
            pps.setInt(6, user.getUser_id());

            pps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }
    }

    public void changePassword(user_info user) {

        PreparedStatement pps = null;
        try {
            conexion();
            String sql = "UPDATE generating.user SET  User_Pass=?  WHERE (User_Email=?)";
            pps = con.prepareStatement(sql);
            pps.setString(1, user.getUser_pass());
            pps.setString(2, user.getUser_email());

            pps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }
    }

    public user_info search_user(String user_email) {

        Statement st = null;
        ResultSet rs = null;
        user_info userInfo = null;

        try {

            conexion();
            st = con.createStatement();
            String sql = "SELECT User_id, User_Email, User_Pass, User_Status, User_Name, User_Type_Id FROM user WHERE User_Email ='" + user_email + "'";
            System.out.println(sql);
            rs = st.executeQuery(sql);
            if (rs.next()) {
                int id = rs.getInt("User_id");
                String email = rs.getString("User_Email");
                String pass = rs.getString("User_Pass");
                String status = rs.getString("User_Status");
                String name = rs.getString("User_Name");
                int type = rs.getInt("User_Type_Id");
                userInfo = new user_info(id, email, pass, status, name, type);

            } else {
                userInfo = null;
            }

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            cerrarResultSet(rs);
            cerrarStatement(st);
            desconectar();

        }

        return userInfo;

    }

    public List<user_info> selectUsers() {

        Statement st = null;
        ResultSet rs = null;
        List<user_info> userList = new ArrayList<>();

        try {
            conexion();
            st = con.createStatement();
            String sql = "SELECT User_Id, User_Email, User_Pass, User_Status, User_Name, User_Type_Id FROM user";
            rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("User_Id");
                String email = rs.getString("User_Email");
                String pass = rs.getString("User_Pass");
                String status = rs.getString("User_Status");
                String name = rs.getString("User_Name");
                int type = rs.getInt("User_Type_Id");
                user_info userInfo = new user_info(id, email, pass, status, name, type);
                userList.add(userInfo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(st);
            desconectar();
        }
        return userList;
    }

    public void deleteUser(user_info user) {
        PreparedStatement pps = null;
        String sql = "DELETE FROM generating.user WHERE User_id=?";

        try {
            conexion();
            pps = con.prepareStatement(sql);
            pps.setInt(1, user.getUser_id());

            pps.executeUpdate();
            System.out.println("user was deleted succesfull");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }

    }
}
