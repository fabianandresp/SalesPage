/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Servicio;

import GeneratingJira.Object.items_selectedTO;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pimie
 */
public class servicio_items_selected extends conexion {

    public void insertarItemSelected(items_selectedTO itemSelected) {

        PreparedStatement pps = null;
        String sql = "INSERT INTO generating.items_selected VALUES(?,?,?,?,?,?)";

        try {
            conexion();
            pps = con.prepareStatement(sql);
            pps.setInt(1, itemSelected.getId_item());
            pps.setInt(2, itemSelected.getId_carrito());
            pps.setInt(3, itemSelected.getItem_cantidad());
            pps.setString(4, itemSelected.getItem_nombre());
            pps.setInt(5, itemSelected.getItem_precio());
            pps.setString(6, itemSelected.getItem_ruta());

            pps.executeUpdate();

            System.out.println("agredando articulo del articulo");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }
    }

    public List<items_selectedTO> lista(int idcarrito) {

        Statement st = null;
        ResultSet rs = null;
        List<items_selectedTO> listItemsSelected = new ArrayList<>();

        try {
            conexion();
            st = con.createStatement();
            String sql = "SELECT id_item, id_carrito, item_cantidad, item_nombre, item_precio, item_ruta FROM generating.items_selected WHERE id_carrito ='" + idcarrito + "'";
            rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id_item");
                int idCarrito = rs.getInt("id_carrito");
                int itemCantidad = rs.getInt("item_cantidad");
                String itemNombre = rs.getString("item_nombre");
                int itemPrecio = rs.getInt("item_precio");
                String ruta = rs.getString("item_ruta");
                items_selectedTO itemSelected = new items_selectedTO(id, idCarrito, itemCantidad, itemNombre, itemPrecio, ruta);
                //itemSelected.setItem_ruta(ruta);
                System.out.println(ruta);
                listItemsSelected.add(itemSelected);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(st);
            desconectar();
        }
        return listItemsSelected;
    }

//    public String imagenRuta(int idItem, int idCarrito) {
//
//        Statement st = null;
//        ResultSet rs = null;
//        String ruta = null;
//
//        try {
//            conexion();
//            st = con.createStatement();
//            String sql = "SELECT us.rutaImagen FROM generating.items us, generating.items_selected ist where us.id ='" + idItem + "' and ist.id_carrito ='" + idCarrito + "'";
//            rs = st.executeQuery(sql);
//
//            while (rs.next()) {
//                ruta = rs.getString("us.rutaImagen");
//                System.out.println(ruta);
//
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            cerrarResultSet(rs);
//            cerrarStatement(st);
//            desconectar();
//        }
//        return ruta;
//    }

    public InputStream imagen(byte[] arr) {

        InputStream input = new ByteArrayInputStream(arr);
        return input;
    }

}
