/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Servicio;

import GeneratingJira.Object.facturaTO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author pimie
 */
public class servicio_facturaTO extends conexion {

    public void insertarFactura(facturaTO factura) {

        PreparedStatement stmt = null;

        try {
            conexion();

            String sql = "INSERT INTO factura (factura_id, factura_date, factura_monto, user_id) VALUES (?,?,?,?)";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, factura.getOrder_id());
            stmt.setString(2, factura.getOrder_date());
            stmt.setInt(3, factura.getOrder_total());
            stmt.setInt(4, factura.getUser_id());
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(stmt);
            desconectar();
        }
    }

    public List<facturaTO> listaFacturas() {

        Statement stmt = null;
        ResultSet rs = null;
        List<facturaTO> listaFactura = new ArrayList<facturaTO>();

        try {
            conexion();
            stmt = con.createStatement();
            String sql = "SELECT * from factura";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {

                int id = rs.getInt("factura_id");
                String fecha = rs.getString("factura_date");
                int montoTotal = rs.getInt("factura_monto");
                int user_id = rs.getInt("user_id");
                facturaTO factura = new facturaTO(id, fecha, montoTotal, user_id);

                listaFactura.add(factura);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        } finally {
            cerrarResultSet(rs);
            cerrarStatement(stmt);
            desconectar();
        }
        return listaFactura;

    }
}
