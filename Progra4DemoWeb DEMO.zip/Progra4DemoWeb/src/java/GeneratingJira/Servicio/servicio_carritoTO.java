/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneratingJira.Servicio;

import GeneratingJira.Object.CarritoTO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import static java.sql.Types.NULL;

/**
 *
 * @author pimie
 */
public class servicio_carritoTO extends conexion {

    private int carrito_id = NULL;

    public void createNewIdCarrito() {

        PreparedStatement pps = null;
        String sql = "INSERT INTO generating.carrito VALUES(?,?,?)";

        try {
            conexion();
            pps = con.prepareStatement(sql);
            pps.setInt(1, carrito_id);
            pps.setDouble(2, NULL);
            pps.setDouble(3, NULL);

            pps.executeUpdate();

            System.out.println("iniciado un nuevo carrito");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }
    }

    public CarritoTO selectIdCarrito() {

        Statement st = null;
        ResultSet rs = null;
        CarritoTO idCart = null;

        try {
            conexion();
            st = con.createStatement();
            String sql = "SELECT carrito_id, carrito_totalPrecio, carrito_cantidadTotal FROM generating.carrito where carrito_id = (select max(carrito_id) from generating.carrito); ";
            rs = st.executeQuery(sql);

            while (rs.next()) {
                int idCarrito = rs.getInt("carrito_id");
                int totalPrize = rs.getInt("carrito_totalPrecio");
                int totalCantidad = rs.getInt("carrito_cantidadTotal");
                idCart = new CarritoTO(idCarrito, totalPrize, totalCantidad);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return idCart;
        
    }
    
    public void updateCarrito(CarritoTO carrito){
                PreparedStatement pps = null;
        try {
            conexion();
            String sql = "UPDATE generating.carrito SET  carrito_totalPrize=?, carrito_cantidadTotal=?  WHERE (carrito_id=?)";
            pps = con.prepareStatement(sql);
            pps.setDouble(1, carrito.getCarrito_totalPrize());
            pps.setDouble(2, carrito.getCarrito_cantidadTotal());
            pps.setInt(3, carrito.getCarrito_id());

            pps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarPrepareStatement(pps);
            desconectar();
        }
    }
    
}
