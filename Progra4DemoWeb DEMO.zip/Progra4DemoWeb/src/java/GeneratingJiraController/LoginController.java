package GeneratingJiraController;

import GeneratingJira.Object.CarritoTO;
import GeneratingJira.Object.ItemTO;
import GeneratingJira.Object.facturaTO;
import GeneratingJira.Object.items_selectedTO;
import GeneratingJira.Object.user_info;
import GeneratingJira.Servicio.servicio_ItemTO;
import GeneratingJira.Servicio.servicio_carritoTO;
import GeneratingJira.Servicio.servicio_facturaTO;
import GeneratingJira.Servicio.servicio_items_selected;
import GeneratingJira.Servicio.servicio_user_info;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import static java.sql.Types.NULL;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import org.primefaces.PrimeFaces;
import org.primefaces.model.chart.PieChartModel;
import org.primefaces.model.file.UploadedFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import org.primefaces.shaded.commons.io.IOUtils;

/**
 *
 * @author pimie
 */
@ManagedBean(name = "loginController")
@SessionScoped

public class LoginController implements Serializable {

    public String header;
    public String name;
    public String mail;
    private int option;
    private String clave;
    private String correo;
    private int countTest;
    private int montoTotal;
    private String fullName;
    private String typeUser;
    private UploadedFile file;
    private List<user_info> usersList;
    private PieChartModel pieModel;
    private user_info selectedUsuario;
    private servicio_ItemTO servicioItem;
    private List<user_info> selectedUsers;
    private servicio_user_info servicioUser;
    private servicio_carritoTO servicioCarrito;
    private servicio_facturaTO servicioFactura;
    private servicio_items_selected servicioItemSelected;
    private user_info user = new user_info();
    private facturaTO factura = new facturaTO();
    private CarritoTO carrito = new CarritoTO();
    private ItemTO selectedItem = new ItemTO();
    private ItemTO selectedItemCarrito = new ItemTO();
    private ZonedDateTime date = ZonedDateTime.now();
    private items_selectedTO itemSelected = new items_selectedTO();

    private List<ItemTO> listaItems = new ArrayList<>();
    private List<facturaTO> listaFacturas = new ArrayList<>();
    private List<items_selectedTO> carritoLista = new ArrayList<>();

    public LoginController() {
    }

    public void ingresar() {
        System.out.println("EL VALOR INGRESADO PARA EL USER ES: " + this.getCorreo());
        System.out.println("EL VALOR INGRESADO PARA EL PASS ES: " + this.getClave());
        System.out.println("LA OPCION SELECCIONADA ES: " + this.getOption());

        //se valida si el campo correo esta vacio o null
        if (this.getCorreo() == null || "".equals(this.getCorreo())) {
            FacesContext.getCurrentInstance().addMessage("sticky-key", new FacesMessage(FacesMessage.SEVERITY_WARN, "Campos Invalidos", "El correo electronico y/o password no puede/n estar vacios"));
        } else {
            servicioItem = new servicio_ItemTO();
            servicioUser = new servicio_user_info();
            servicioCarrito = new servicio_carritoTO();
            servicioFactura = new servicio_facturaTO();
            servicioItemSelected = new servicio_items_selected();

            user = servicioUser.search_user(correo);

            if (user != null && user.getUser_type() == this.getOption() && user.getUser_pass().equals(this.getClave())) {
                this.usersList = servicioUser.selectUsers(); //obtener todos los usuarios
                this.listaItems = servicioItem.listarItems(); //obtener todos los prductos (Items) 
                servicioCarrito.createNewIdCarrito();
                carrito = servicioCarrito.selectIdCarrito(); //almacena el id del carrito para la sesion
                this.carritoLista = servicioItemSelected.lista(carrito.getCarrito_id());
                this.redireccionar("/faces/productos.xhtml"); //Redireccionar a otra pagina

            } else {
                FacesContext.getCurrentInstance().addMessage("sticky-key", new FacesMessage(FacesMessage.SEVERITY_FATAL, "Campos Invalidos", "El correo electronico y/o password y/o tipo de usuario seleccionado estan incorrecto"));
            }
        }
    }

    //Cerrar Sesion
    public void back() {
        try {
            FacesContext context = FacesContext.getCurrentInstance();
            context.getExternalContext().invalidateSession();
            context.getExternalContext().redirect("index.xhtml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Funcion para redireccionar
    public void redireccionar(String ruta) {
        HttpServletRequest request;
        try {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            FacesContext.getCurrentInstance().getExternalContext().redirect(request.getContextPath() + ruta);
        } catch (Exception e) {

        }
    }

    public void openNew() {
        this.selectedUsuario = new user_info();
        System.out.println("creando nuevo usuario");
    }

    public void openNewItem() {
        this.selectedItem = new ItemTO();
    }

    //Ingresa un usuario o actualiza un usuario de acuerdo a su ID 
    public void saveUser() {
        if (this.carrito.getCarrito_id() == NULL) {
            servicioUser = new servicio_user_info();
        }
        if (this.selectedUsuario.getUser_id() == NULL) {
            this.servicioUser.user_info_insert(this.selectedUsuario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Added"));
            this.selectedUsuario = null;
        } else {
            this.servicioUser.updateUser(this.selectedUsuario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Updated"));
            this.selectedUsuario = null;
        }
        this.usersList = this.servicioUser.selectUsers();
        PrimeFaces.current().executeScript("PF('manageUserDialog').hide()");
        PrimeFaces.current().ajax().update("form:messages", "form:dt-users");
    }

    public void guardarUsuario() {
        this.selectedUsuario = new user_info();
        this.selectedUsuario.setUser_status("ACTIVO");
        this.selectedUsuario.setUser_type(2);
        System.out.println(this.selectedUsuario.getUser_status());
        System.out.println(this.selectedUsuario.getUser_email());
        System.out.println(this.selectedUsuario.getUser_name());
        System.out.println(this.selectedUsuario.getUser_pass());
        System.out.println(this.selectedUsuario.getUser_type());
        System.out.println(this.selectedUsuario.getUser_id());
        this.servicioUser.user_info_insert(this.selectedUsuario);

    }

    //Cambia el password de un usuario de acuerdo a su correo
    public void changePassword() {
        if (this.carrito.getCarrito_id() == NULL) {
            servicioUser = new servicio_user_info();
        }
        this.servicioUser.changePassword(this.selectedUsuario);
    }

    public void deleteUser() {
        this.servicioUser.deleteUser(this.selectedUsuario);
        this.selectedUsuario = null;
        this.usersList = this.servicioUser.selectUsers();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Deleted"));
        PrimeFaces.current().ajax().update("form:messages", "form:dt-users");
        PrimeFaces.current().executeScript("PF('manageUserDialog').hide()");
    }

    // No en uso
    public String getDeleteButtonMessage() {
        if (hasSelectedUsers()) {
            int size = this.selectedUsers.size();
            return size > 1 ? size + " products selected" : "1 product selected";
        }
        return "Delete";
    }

    // No en uso
    public boolean hasSelectedUsers() {
        return this.selectedUsers != null && !this.selectedUsers.isEmpty();
    }

    //No es uso
    public void nuevoRegistro() {
        this.selectedUsuario = new user_info();
        this.redireccionar("/faces/registerNewUser.xhtml");
    }

    public void saveItem() throws IOException {
        if (this.selectedItem.getId() == NULL) {
            upload();
            this.servicioItem.insertar(this.selectedItem);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Item Added"));
            this.selectedItem = null;
        } else {
            upload();
            this.servicioItem.actualizar(this.selectedItem);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Item Updated"));
            this.selectedItem = null;
        }
        this.listaItems = this.servicioItem.listarItems();
        PrimeFaces.current().executeScript("PF('manageUserDialog').hide()");
        PrimeFaces.current().ajax().update("form:messages", "form:dt-users");
    }

    public void deleteItem() {
        File fi = new File(this.servicioItem.pathImagen() + "\\" + this.selectedItem.getNombreImagen());
        fi.delete();
        this.servicioItem.eliminar(this.selectedItem);
        this.listaItems = servicioItem.listarItems();

        PrimeFaces.current().ajax().update("form:messages", "form:dt-users");
        PrimeFaces.current().executeScript("PF('manageUserDialog').hide()");
    }

    public void addCarrito() throws IOException {
        this.selectedItemCarrito = this.selectedItem;
        if (this.selectedItem.getId() != NULL && this.selectedItem.getCantidad() >= this.countTest) {
            int count = this.selectedItem.getCantidad() - this.countTest;
            this.selectedItem.setCantidad(count);
            this.servicioItem.actualizar(selectedItem);
            this.selectedItemCarrito.setCantidad(this.countTest);

            this.itemSelected.setId_item(this.selectedItem.getId());
            this.itemSelected.setId_carrito(this.carrito.getCarrito_id());
            this.itemSelected.setItem_cantidad(this.countTest);
            this.itemSelected.setItem_nombre(this.selectedItem.getNombreItem());
            this.itemSelected.setItem_precio(this.selectedItem.getPrecioItem());
            this.itemSelected.setItem_ruta(this.selectedItem.getRutaImagen());
            servicioItemSelected.insertarItemSelected(itemSelected);
        }
        this.montoTotal = this.montoTotal + (this.countTest * this.selectedItem.getPrecioItem());
        this.listaItems = this.servicioItem.listarItems();
        this.carritoLista = this.servicioItemSelected.lista(this.carrito.getCarrito_id());
        PrimeFaces.current().executeScript("PF('manageUserDialog').hide()");
        PrimeFaces.current().ajax().update("form:messages", "form:dt-users");
    }

    public void upload() throws IOException {
        if (file != null) {
            InputStream fi = file.getInputStream();
            String nombre = file.getFileName();
            this.guardarImagen(fi, nombre);
            FacesMessage message = new FacesMessage("Successful", file.getFileName() + " is uploaded.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }

    public void guardarImagen(InputStream is, String fileName) throws FileNotFoundException, IOException {

        String extension = "";
        File fi = new File(this.servicioItem.pathImagen() + "\\" + this.selectedItem.getNombreImagen());
        if (!fi.exists()) {

            if (fileName.endsWith(".jpg")) {
                extension = ".jpg";
            }
            if (fileName.endsWith(".png")) {
                extension = ".png";
            }

            //String[] part = fileName.split("\\.");
            //String part2 = part[1];
            int a = servicioItem.maxId();
            fileName = Integer.toString(a) + extension;
            File k = new File(this.servicioItem.pathImagen(), fileName);

            this.selectedItem.setNombreImagen(k.getName());
            this.selectedItem.setRutaImagen(this.servicioItem.urlImagen() + fileName);
            OutputStream out = new FileOutputStream(k);

            try {
                IOUtils.copy(is, out);
            } finally {
                IOUtils.closeQuietly(is);
                IOUtils.closeQuietly(out);
            }

        } else {
            System.out.println(fileName);
            String nombreViejo = fi.getName();
            fileName = nombreViejo;
            //tambien hay que cambiar el como guarda el nombre, hay un error si se cambia 
            //de un jpg a un png
            fi.delete();
            File k = new File(this.servicioItem.pathImagen(), fileName);
            System.out.println(k.getName());
            System.out.println(k.getAbsolutePath());

            //le pasa lo mismo que al insertar, hay que refrescar para que muestre la imagen
            this.selectedItem.setNombreImagen(k.getName());
            this.selectedItem.setRutaImagen(this.servicioItem.urlImagen() + fileName);
            OutputStream out = new FileOutputStream(k);

            try {
                IOUtils.copy(is, out);
            } finally {
                IOUtils.closeQuietly(is);
                IOUtils.closeQuietly(out);
            }
        }
    }

    public void facturar() {
        this.factura.setOrder_id(this.crearNumeroFactura());
        this.factura.setOrder_date(this.date.toString());
        this.factura.setOrder_total(this.montoTotal);
        this.factura.setUser_id(this.user.getUser_id());
        this.servicioFactura.insertarFactura(factura);
        System.out.println(this.crearNumeroFactura());
        System.out.println(this.date.toString());
        System.out.println(this.montoTotal);
        System.out.println(this.user.getUser_id());
        this.redireccionar("/faces/factura.xhtml");
    }

    public int crearNumeroFactura() {
        int min = 1;
        int max = 10;
        int getRandomValue = 0;
        for (int i = min; i <= max; i++) {
            getRandomValue = (int) (Math.random() * (max - min)) + min;

        }
        return getRandomValue;
    }

    public void volver() {
        this.redireccionar("/faces/productos.xhtml");
        servicioCarrito.createNewIdCarrito();
        carrito = servicioCarrito.selectIdCarrito(); //almacena el id del carrito para la sesion

    }

    private void graficar(List<ItemTO> Item) {

        pieModel = new PieChartModel();
        for (ItemTO ITO : Item) {
            pieModel.set(ITO.getNombreItem(), ITO.getCantidad());
        }
        pieModel.setTitle("Precio");
        pieModel.setLegendPosition("e");
        pieModel.setFill(false);
        pieModel.setShowDataLabels(true);
        pieModel.setDiameter(150);

    }

    public void listar() {
        servicio_ItemTO servicio = new servicio_ItemTO();
        List<ItemTO> listar;
        try {
            listar = servicio.listarItems();
            graficar(listar);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }
    }

    public void sendMail() {
        final String username = "juanvaldeztest2022@gmail.com";
        final String password = "Juanvaldez2022";
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });
        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("carritocomprastest20201"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(this.correo));
            message.setSubject("Facturacion de orden a nombre de " + this.getCorreo());
            message.setText("Hola " + this.getCorreo() + " Este es un mensaje que confirma la compra hecha el dia de hoy /n"
                    + "Factura: " + this.factura.getOrder_id() + " Con el precio: " + this.factura.getOrder_total() + "/n agradecemos su preferencia");

            Transport.send(message);

        } catch (MessagingException ex) {
            throw new RuntimeException(ex);
        }
    }

    //GETS AND SETTERS
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getTypeUser() {
        return typeUser;
    }

    public void setTypeUser(String typeUser) {
        this.typeUser = typeUser;
    }

    public List<user_info> getUsersList() {
        return usersList;
    }

    public void setUsersList(List<user_info> usersList) {
        this.usersList = usersList;
    }

    public user_info getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(user_info selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public int getOption() {
        return option;
    }

    public void setOption(int option) {
        this.option = option;
    }

    public List<user_info> getselectedUsers() {
        return selectedUsers;
    }

    public void setselectedUsers(List<user_info> selectedProducts) {
        this.selectedUsers = selectedUsers;
    }

    public List<ItemTO> getListaItems() {
        return listaItems;
    }

    public void setListaItems(List<ItemTO> listaItems) {
        this.listaItems = listaItems;
    }

    public ItemTO getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(ItemTO selectedItem) {
        this.selectedItem = selectedItem;
    }

    public List<items_selectedTO> getCarritoLista() {
        return carritoLista;
    }

    public void setCarritoLista(List<items_selectedTO> carritoLista) {
        this.carritoLista = carritoLista;
    }

    public int getCountTest() {
        return countTest;
    }

    public void setCountTest(int countTest) {
        this.countTest = countTest;
    }

    public items_selectedTO getItemSelected() {
        return itemSelected;
    }

    public void setItemSelected(items_selectedTO itemSelected) {
        this.itemSelected = itemSelected;
    }

    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }

    public int getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(int montoTotal) {
        this.montoTotal = montoTotal;
    }

    public facturaTO getFactura() {
        return factura;
    }

    public void setFactura(facturaTO factura) {
        this.factura = factura;
    }

    public CarritoTO getCarrito() {
        return carrito;
    }

    public void setCarrito(CarritoTO carrito) {
        this.carrito = carrito;
    }

    public PieChartModel getPieModel() {
        return pieModel;
    }

    public void setPieModel(PieChartModel pieModel) {
        this.pieModel = pieModel;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

}
